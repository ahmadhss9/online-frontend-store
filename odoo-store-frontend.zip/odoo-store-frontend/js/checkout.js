// Checkout functionality
class Checkout {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
        this.init();
    }
    
    init() {
        if (window.location.pathname.includes('checkout.html')) {
            this.renderOrderReview();
            this.setupFormValidation();
        }
    }
    
    renderOrderReview() {
        const orderItems = document.getElementById('orderItems');
        const reviewSubtotal = document.getElementById('reviewSubtotal');
        const reviewTax = document.getElementById('reviewTax');
        const reviewTotal = document.getElementById('reviewTotal');
        
        if (this.cart.length === 0) {
            window.location.href = 'cart.html';
            return;
        }
        
        // Calculate totals
        let subtotal = 0;
        
        // Generate order items HTML
        orderItems.innerHTML = this.cart.map(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            
            return `
                <div class="review-item">
                    <span class="item-name">${item.name} × ${item.quantity}</span>
                    <span class="item-total">₹${itemTotal.toLocaleString()}</span>
                </div>
            `;
        }).join('');
        
        // Calculate totals
        const shipping = 50;
        const tax = subtotal * 0.18;
        const total = subtotal + shipping + tax;
        
        // Update summary
        reviewSubtotal.textContent = `₹${subtotal.toLocaleString()}`;
        reviewTax.textContent = `₹${tax.toFixed(2)}`;
        reviewTotal.textContent = `₹${total.toFixed(2)}`;
    }
    
    setupFormValidation() {
        const form = document.getElementById('checkoutForm');
        
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.placeOrder();
        });
    }
    
    placeOrder() {
        const form = document.getElementById('checkoutForm');
        
        if (this.cart.length === 0) {
            alert('Your cart is empty!');
            window.location.href = 'cart.html';
            return;
        }
        
        // Validate form
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        // Get form data
        const orderData = {
            orderId: 'ORD' + Date.now(),
            customer: {
                name: document.getElementById('name').value,
                phone1: document.getElementById('phone1').value,
                phone2: document.getElementById('phone2').value || 'Not provided',
                address: document.getElementById('address').value,
                city: document.getElementById('city').value,
                payment: document.getElementById('payment').value
            },
            items: this.cart,
            subtotal: document.getElementById('reviewSubtotal').textContent,
            tax: document.getElementById('reviewTax').textContent,
            shipping: '₹50',
            total: document.getElementById('reviewTotal').textContent,
            date: new Date().toLocaleString(),
            status: 'pending'
        };
        
        // Store order in localStorage
        const orders = JSON.parse(localStorage.getItem('orders')) || [];
        orders.push(orderData);
        localStorage.setItem('orders', JSON.stringify(orders));
        
        // Clear cart
        localStorage.removeItem('cart');
        
        // Show success message
        this.showOrderSuccess(orderData);
    }
    
    showOrderSuccess(orderData) {
        const successHTML = `
            <div class="order-success" style="
                background: white;
                border-radius: 15px;
                padding: 40px;
                text-align: center;
                max-width: 600px;
                margin: 40px auto;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            ">
                <div style="
                    background: #4CAF50;
                    width: 80px;
                    height: 80px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 30px;
                ">
                    <i class="fas fa-check" style="color: white; font-size: 2.5rem;"></i>
                </div>
                
                <h2 style="color: #2c3e50; margin-bottom: 15px;">Order Placed Successfully!</h2>
                <p style="color: #7f8c8d; margin-bottom: 25px;">
                    Thank you for your purchase. Your order has been confirmed and will be shipped soon.
                </p>
                
                <div style="
                    background: #f8f9fa;
                    border-radius: 10px;
                    padding: 20px;
                    margin: 25px 0;
                    text-align: left;
                ">
                    <h3 style="color: #2c3e50; margin-bottom: 15px;">Order Summary</h3>
                    <div style="display: grid; gap: 10px;">
                        <div style="display: flex; justify-content: space-between;">
                            <span>Order ID:</span>
                            <strong>${orderData.orderId}</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Date:</span>
                            <span>${orderData.date}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Total Amount:</span>
                            <strong style="color: #4CAF50; font-size: 1.2rem;">${orderData.total}</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Payment Method:</span>
                            <span>${orderData.customer.payment.toUpperCase()}</span>
                        </div>
                    </div>
                </div>
                
                <p style="color: #7f8c8d; font-size: 0.9rem; margin-bottom: 30px;">
                    <i class="fas fa-phone"></i> We'll contact you on ${orderData.customer.phone1} for confirmation.
                </p>
                
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <a href="index.html" style="
                        background: #4CAF50;
                        color: white;
                        padding: 12px 25px;
                        border-radius: 8px;
                        text-decoration: none;
                        font-weight: 600;
                        transition: all 0.3s ease;
                    " onmouseover="this.style.backgroundColor='#45a049'" 
                     onmouseout="this.style.backgroundColor='#4CAF50'">
                        <i class="fas fa-home"></i> Back to Home
                    </a>
                    <a href="cart.html" style="
                        background: #3498db;
                        color: white;
                        padding: 12px 25px;
                        border-radius: 8px;
                        text-decoration: none;
                        font-weight: 600;
                        transition: all 0.3s ease;
                    " onmouseover="this.style.backgroundColor='#2980b9'" 
                     onmouseout="this.style.backgroundColor='#3498db'">
                        <i class="fas fa-shopping-cart"></i> View Cart
                    </a>
                </div>
            </div>
        `;
        
        // Replace checkout content with success message
        const checkoutContainer = document.querySelector('.checkout-container');
        if (checkoutContainer) {
            checkoutContainer.innerHTML = successHTML;
        }
        
        // Update cart count
        document.querySelectorAll('.cart-count').forEach(el => {
            el.textContent = '0';
        });
    }
}

// Initialize checkout when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.checkout = new Checkout();
});