class Cart {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
        this.init();
    }
    
    init() {
        // Update cart count on load
        this.updateCartCount();
        
        // Add event listeners for add to cart buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.add-to-cart-btn')) {
                const button = e.target.closest('.add-to-cart-btn');
                if (!button.disabled) {
                    this.addToCartFromButton(button);
                }
            }
        });
        
        // Initialize cart if on cart page
        if (window.location.pathname.includes('cart.html')) {
            this.renderCart();
        }
    }
    
    addToCartFromButton(button) {
        const product = {
            id: button.dataset.id,
            name: button.dataset.name,
            price: parseFloat(button.dataset.price),
            image: button.dataset.image,
            quantity: 1
        };
        
        this.addToCart(product);
    }
    
    addToCart(product) {
        // Check if product already exists in cart
        const existingIndex = this.cart.findIndex(item => item.id === product.id);
        
        if (existingIndex > -1) {
            // Update quantity
            this.cart[existingIndex].quantity += product.quantity;
        } else {
            // Add new product
            this.cart.push(product);
        }
        
        this.saveCart();
        this.updateCartCount();
        this.showNotification(`${product.name} added to cart!`);
    }
    
    removeItem(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartCount();
        this.renderCart();
    }
    
    updateQuantity(productId, change) {
        const itemIndex = this.cart.findIndex(item => item.id === productId);
        
        if (itemIndex > -1) {
            this.cart[itemIndex].quantity += change;
            
            // Remove if quantity becomes 0 or less
            if (this.cart[itemIndex].quantity <= 0) {
                this.cart.splice(itemIndex, 1);
            }
            
            this.saveCart();
            this.updateCartCount();
            this.renderCart();
        }
    }
    
    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.cart));
    }
    
    updateCartCount() {
        const count = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        document.querySelectorAll('.cart-count').forEach(el => {
            el.textContent = count;
        });
    }
    
    renderCart() {
        const cartItems = document.getElementById('cartItems');
        const subtotalEl = document.getElementById('subtotal');
        const taxEl = document.getElementById('tax');
        const totalEl = document.getElementById('total');
        
        if (!cartItems) return;
        
        if (this.cart.length === 0) {
            cartItems.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart fa-3x"></i>
                    <h3>Your cart is empty</h3>
                    <p>Looks like you haven't added any items to your cart yet.</p>
                    <a href="index.html" class="cta-button">Start Shopping</a>
                </div>
            `;
            
            if (subtotalEl) subtotalEl.textContent = '₹0';
            if (taxEl) taxEl.textContent = '₹0';
            if (totalEl) totalEl.textContent = '₹0';
            return;
        }
        
        // Calculate totals
        let subtotal = 0;
        
        // Generate cart items HTML
        cartItems.innerHTML = this.cart.map(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;
            
            return `
                <div class="cart-item" data-id="${item.id}">
                    <img src="${item.image || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=150&auto=format&fit=crop'}" 
                         alt="${item.name}">
                    
                    <div class="item-details">
                        <h3>${item.name}</h3>
                        <p class="item-price">₹${item.price.toLocaleString()}</p>
                    </div>
                    
                    <div class="item-quantity">
                        <button onclick="window.cart.updateQuantity('${item.id}', -1)">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="window.cart.updateQuantity('${item.id}', 1)">+</button>
                    </div>
                    
                    <div class="item-total">
                        ₹${itemTotal.toLocaleString()}
                    </div>
                    
                    <button class="remove-item" onclick="window.cart.removeItem('${item.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        }).join('');
        
        // Calculate totals
        const shipping = 50;
        const tax = subtotal * 0.18;
        const total = subtotal + shipping + tax;
        
        // Update summary
        if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toLocaleString()}`;
        if (taxEl) taxEl.textContent = `₹${tax.toFixed(2)}`;
        if (totalEl) totalEl.textContent = `₹${total.toFixed(2)}`;
    }
    
    showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'cart-notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 10000;
            animation: slideIn 0.3s ease;
            font-weight: 500;
        `;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    getCart() {
        return this.cart;
    }
    
    clearCart() {
        this.cart = [];
        this.saveCart();
        this.updateCartCount();
        this.renderCart();
    }
}

// Initialize cart when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.cart = new Cart();
    
    // Add slide animations for notifications
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
});