// Sample products data
const products = [
    {
        id: '1',
        name: 'Wireless Headphones',
        description: 'Premium noise cancellation headphones with 30-hour battery life',
        price: 2999,
        discountPrice: 2499,
        stockStatus: 'in_stock',
        images: [
            'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=600&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=600&auto=format&fit=crop'
        ],
        category: 'Electronics',
        rating: 4.5,
        reviews: 128
    },
    {
        id: '2',
        name: 'Smart Watch Series 5',
        description: 'Fitness tracker with heart monitor and GPS',
        price: 5999,
        discountPrice: 4999,
        stockStatus: 'in_stock',
        images: [
            'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600&auto=format&fit=crop'
        ],
        category: 'Electronics',
        rating: 4.2,
        reviews: 89
    },
    {
        id: '3',
        name: 'Laptop Backpack',
        description: 'Water-resistant laptop bag with USB charging port',
        price: 1999,
        discountPrice: 1599,
        stockStatus: 'in_stock',
        images: [
            'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1585916420730-d7f95e942d43?w=600&auto=format&fit=crop'
        ],
        category: 'Accessories',
        rating: 4.7,
        reviews: 203
    },
    {
        id: '4',
        name: 'Fast Phone Charger',
        description: 'USB-C fast charging cable with adapter',
        price: 999,
        discountPrice: null,
        stockStatus: 'in_stock',
        images: [
            'https://images.unsplash.com/photo-1605792657660-596af9009e82?w=600&auto=format&fit=crop',
            'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=600&auto=format&fit=crop'
        ],
        category: 'Electronics',
        rating: 4.0,
        reviews: 56
    },
    {
        id: '5',
        name: 'Bluetooth Speaker',
        description: 'Portable waterproof speaker with 360° sound',
        price: 3499,
        discountPrice: 2999,
        stockStatus: 'out_of_stock',
        images: [
            'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600&auto=format&fit=crop'
        ],
        category: 'Electronics',
        rating: 4.8,
        reviews: 167
    },
    {
        id: '6',
        name: 'Wireless Mouse',
        description: 'Ergonomic wireless mouse with silent clicks',
        price: 1299,
        discountPrice: 999,
        stockStatus: 'in_stock',
        images: [
            'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600&auto=format&fit=crop'
        ],
        category: 'Electronics',
        rating: 4.3,
        reviews: 92
    }
];

// Load products on home page
function loadProducts() {
    const productsGrid = document.getElementById('productsGrid');
    const similarProducts = document.getElementById('similarProducts');
    
    if (productsGrid) {
        productsGrid.innerHTML = products.map(product => `
            <div class="product-card">
                <div class="product-image">
                    <img src="${product.images[0]}" alt="${product.name}">
                    ${product.discountPrice ? `<span class="discount-badge">Save ₹${product.price - product.discountPrice}</span>` : ''}
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p class="description">${product.description}</p>
                    <div class="price">
                        ${product.discountPrice ? `
                            <span class="original-price">₹${product.price.toLocaleString()}</span>
                            <span class="discount-price">₹${product.discountPrice.toLocaleString()}</span>
                        ` : `
                            <span class="current-price">₹${product.price.toLocaleString()}</span>
                        `}
                    </div>
                    <div class="stock-status ${product.stockStatus}">
                        ${product.stockStatus === 'in_stock' ? 'In Stock' : 'Out of Stock'}
                    </div>
                    <button class="add-to-cart-btn" 
                            data-id="${product.id}"
                            data-name="${product.name}"
                            data-price="${product.discountPrice || product.price}"
                            data-image="${product.images[0]}"
                            ${product.stockStatus === 'out_of_stock' ? 'disabled' : ''}>
                        <i class="fas fa-shopping-cart"></i> 
                        ${product.stockStatus === 'in_stock' ? 'Add to Cart' : 'Out of Stock'}
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    // Load similar products on product detail page
    if (similarProducts) {
        // Show 4 random products as similar products
        const randomProducts = [...products]
            .sort(() => 0.5 - Math.random())
            .slice(0, 4);
        
        similarProducts.innerHTML = randomProducts.map(product => `
            <div class="product-card">
                <div class="product-image">
                    <img src="${product.images[0]}" alt="${product.name}">
                </div>
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <div class="price">
                        ${product.discountPrice ? `
                            <span class="original-price">₹${product.price.toLocaleString()}</span>
                            <span class="discount-price">₹${product.discountPrice.toLocaleString()}</span>
                        ` : `
                            <span class="current-price">₹${product.price.toLocaleString()}</span>
                        `}
                    </div>
                    <button class="add-to-cart-btn" 
                            data-id="${product.id}"
                            data-name="${product.name}"
                            data-price="${product.discountPrice || product.price}"
                            data-image="${product.images[0]}">
                        <i class="fas fa-shopping-cart"></i> Add to Cart
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    updateCartCount();
});

// Update cart count from localStorage
function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelectorAll('.cart-count').forEach(el => {
        el.textContent = count;
    });
}